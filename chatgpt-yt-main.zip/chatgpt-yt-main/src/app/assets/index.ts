import logo from "./images/logo.png";
import logoLight from "./images/logoLight.png";
import googleImage from "./images/googleImage.png";
import githubImage from "./images/githubImage.png";

export { logo, logoLight, googleImage, githubImage };
